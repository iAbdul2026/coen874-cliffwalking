import json, os, sys
import numpy as np
import pytest
import gymnasium as gym

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from agents import run_agent, td_target
from cliff_mdp import (GOAL, N_ACTIONS, N_STATES, START, SlipCliffWalkingEnv, build_tables,
                       eps_greedy_policy, policy_value_capped, policy_value_exact, value_iteration)

CFG = dict(epsilon=0.1, gamma=1.0, train_steps=1500, episode_cap=200, eval_every=500, eval_episodes=3,
           threshold_fraction=0.1, q_init=0.0)


def _agg(entries):
    d = {}
    for p, ns, r, t in entries:
        key = (int(ns), float(r), bool(t))
        d[key] = d.get(key, 0.0) + p
    return d


@pytest.mark.parametrize("slip,kw", [(0.0, {}), (2 / 3, {"is_slippery": True})])
def test_tables_match_gymnasium(slip, kw):
    P = gym.make("CliffWalking-v1", **kw).unwrapped.P
    tb = build_tables(slip)
    for s in range(N_STATES):
        if s == GOAL:
            continue
        for a in range(N_ACTIONS):
            ours = _agg([(tb.p[s, a, k], tb.ns[s, a, k], tb.r[s, a, k], tb.term[s, a, k]) for k in range(3)
                         if tb.p[s, a, k] > 0])
            ref = _agg(P[s][a])
            assert ours.keys() == ref.keys(), (s, a)
            for k in ours:
                assert ours[k] == pytest.approx(ref[k])


def test_probabilities_sum_to_one():
    for slip in (0.0, 0.1, 0.5, 1.0):
        assert np.allclose(build_tables(slip).p.sum(2), 1.0)


def test_deterministic_optimum_is_13_steps():
    V, _ = value_iteration(build_tables(0.0))
    assert V[START] == pytest.approx(-13.0)


def test_optimum_worsens_with_slip():
    vals = [value_iteration(build_tables(s))[0][START] for s in (0.0, 0.1, 0.3, 0.5)]
    assert all(a > b for a, b in zip(vals, vals[1:]))


def test_capped_value_matches_exact_when_cap_large():
    tb = build_tables(0.1)
    V, Q = value_iteration(tb)
    pi = eps_greedy_policy(Q, 0.1)
    assert policy_value_capped(tb, pi, 3000)[START] == pytest.approx(policy_value_exact(tb, pi)[START], rel=1e-6)


def test_td_targets_hand_computed():
    q = [1.0, 3.0, 2.0, 0.0]; r, g, eps = -1.0, 1.0, 0.1
    assert td_target("qlearning", q, None, r, False, g, eps) == pytest.approx(-1 + 3.0)
    assert td_target("sarsa", q, 2, r, False, g, eps) == pytest.approx(-1 + 2.0)
    assert td_target("expected_sarsa", q, None, r, False, g, eps) == pytest.approx(-1 + 0.9 * 3.0 + 0.1 * 1.5)
    for algo in ("qlearning", "sarsa", "expected_sarsa"):
        assert td_target(algo, q, 1, r, True, g, eps) == r          # terminal: no bootstrap


def test_expected_sarsa_equals_qlearning_when_greedy():
    q = [0.5, -2.0, 4.0, 1.0]
    assert td_target("expected_sarsa", q, None, -1, False, 1.0, 0.0) == td_target("qlearning", q, None, -1, False, 1.0, 0.0)


def test_truncation_is_not_termination():
    env = SlipCliffWalkingEnv(0.0, max_steps=3)
    env.reset(seed=0)
    out = [env.step(3) for _ in range(3)]       # keep bumping into the left wall
    assert out[-1][3] is True and out[-1][2] is False
    env2 = SlipCliffWalkingEnv(0.0, max_steps=100)
    env2.reset(seed=0)
    env2.s = 35                                  # next to the goal, step down
    assert env2.step(2)[2] is True               # goal = terminated


def test_cliff_resets_to_start_without_terminating():
    env = SlipCliffWalkingEnv(0.0, 100)
    env.reset(seed=0)
    s2, r, term, trunc, info = env.step(2)                    # start is 36 (bottom-left); down is a wall: stay
    assert (s2, r, info["fell"]) == (START, -1.0, False)
    s2, r, term, trunc, info = env.step(1)                    # right of start = cliff
    assert (s2, r, term, info["fell"]) == (START, -100.0, False, True)


def test_same_seed_reproducible_and_different_seed_differs():
    a = run_agent("sarsa", 0.3, 0.3, 7, CFG); b = run_agent("sarsa", 0.3, 0.3, 7, CFG)
    c = run_agent("sarsa", 0.3, 0.3, 8, CFG)
    assert np.array_equal(a["ep_returns"], b["ep_returns"]) and np.array_equal(a["q_final"], b["q_final"])
    assert not np.array_equal(a["q_final"], c["q_final"])


def test_equal_step_budget():
    for algo in ("qlearning", "sarsa", "expected_sarsa", "random"):
        r = run_agent(algo, 0.1, 0.3, 0, CFG)
        assert r["eval_steps"][-1] == CFG["train_steps"]


def test_q_learning_learns_deterministic_cliff():
    cfg = dict(CFG, train_steps=20000, episode_cap=500, eval_every=5000)
    r = run_agent("qlearning", 0.0, 0.5, 0, cfg)
    assert r["eval_exact"][-1] == pytest.approx(-13.0)    # greedy policy reaches the optimum


def test_slip_is_sideways_only():
    """Documents the transition model: intended move 1-p, each perpendicular move p/2, never the opposite."""
    tb = build_tables(0.3)
    s, a = 13, 0                                   # row 1, col 1; intended action = up
    assert list(tb.ns[s, a]) == [1, 12, 14]        # up, left, right; down (25) is impossible
    assert list(tb.p[s, a]) == pytest.approx([0.7, 0.15, 0.15])
    assert 25 not in set(tb.ns[s, a])


def test_episode_return_identity_return_equals_minus_length_minus_99_falls():
    """Every step costs -1 and a fall costs an extra -99, so safety and efficiency together make up online return."""
    for algo in ("qlearning", "sarsa", "expected_sarsa", "random"):
        r = run_agent(algo, 0.5, 0.3, 3, dict(CFG, train_steps=4000))
        assert len(r["ep_returns"]) > 5
        assert np.allclose(r["ep_returns"], -r["ep_lens"].astype(float) - 99.0 * r["ep_falls"])


def test_fall_rate_counts_every_fall():
    r = run_agent("random", 0.3, 0.0, 1, dict(CFG, train_steps=3000))
    assert r["scores"]["total_falls"] >= int(r["ep_falls"].sum())          # the last unfinished episode is not in ep_falls
    assert r["scores"]["fall_rate_per_1k"] == pytest.approx(1000.0 * r["scores"]["total_falls"] / 3000)


def test_global_generators_are_seeded():
    import random
    run_agent("sarsa", 0.3, 0.3, 5, dict(CFG, train_steps=500)); a = (random.random(), np.random.rand())
    run_agent("sarsa", 0.3, 0.3, 5, dict(CFG, train_steps=500)); b = (random.random(), np.random.rand())
    assert a == b
