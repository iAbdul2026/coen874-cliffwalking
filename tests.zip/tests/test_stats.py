import os, sys
import numpy as np
import pytest
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from stats_utils import boot_ci, boot_diff_ci, hedges_g, holm, rank_biserial, welch_anova


def test_holm_known_example():
    assert holm([0.01, 0.04, 0.03]) == pytest.approx([0.03, 0.06, 0.06])
    assert holm([0.5]) == pytest.approx([0.5])
    assert holm([0.9, 0.8]) == pytest.approx([1.0, 1.0])           # 2 x 0.8 = 1.6 is capped at 1, and adjusted p stays monotone


def test_holm_never_below_raw_p_and_not_above_one():
    p = np.random.default_rng(0).uniform(size=20)
    h = holm(p)
    assert np.all(h >= p - 1e-12) and np.all(h <= 1.0)


def test_welch_anova_two_groups_equals_welch_t_squared():
    rng = np.random.default_rng(1)
    a, b = rng.normal(0, 1, 30), rng.normal(0.5, 3, 40)
    F, d1, d2, p = welch_anova([a, b])
    t = stats.ttest_ind(a, b, equal_var=False)
    assert F == pytest.approx(t.statistic ** 2) and p == pytest.approx(t.pvalue) and d2 == pytest.approx(t.df)


def test_welch_anova_detects_difference_and_is_roughly_calibrated_under_null():
    rng = np.random.default_rng(2)
    assert welch_anova([rng.normal(0, 1, 50), rng.normal(0, 2, 50), rng.normal(2, 3, 50)])[3] < 1e-3
    ps = [welch_anova([rng.normal(0, s, 30) for s in (1, 2, 3)])[3] for _ in range(1500)]
    assert 0.03 < np.mean(np.array(ps) < 0.05) < 0.07


def test_effect_sizes():
    a, b = np.array([1.0, 2, 3, 4, 5]), np.array([6.0, 7, 8, 9, 10])
    assert rank_biserial(a, b) == pytest.approx(-1.0) and rank_biserial(b, a) == pytest.approx(1.0)
    rng = np.random.default_rng(3)
    x, y = rng.normal(1.0, 1, 4000), rng.normal(0.0, 1, 4000)
    assert hedges_g(x, y) == pytest.approx(1.0, abs=0.08)
    assert np.isnan(hedges_g([1.0, 1.0, 1.0], [1.0, 1.0, 1.0]))


def test_bootstrap_cis_contain_estimate():
    rng = np.random.default_rng(4); x = rng.normal(5, 2, 50); y = rng.normal(3, 2, 50)
    lo, hi = boot_ci(x, np.mean, 2000, np.random.default_rng(0)); assert lo < x.mean() < hi
    lo, hi = boot_diff_ci(x, y, 2000, np.random.default_rng(0)); assert lo < x.mean() - y.mean() < hi and lo > 0
